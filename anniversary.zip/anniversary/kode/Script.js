// ==========================================
// BECHAROUND - JAVASCRIPT
// ==========================================

// 1. HITUNG MUNDUR ANNIVERSARY
const countdown = document.getElementById("countdown");

// Tanggal anniversary: 5 November 2026
const anniversaryDate = new Date("2026-11-05T00:00:00").getTime();

function updateCountdown() {
if (!countdown) return;

const now = new Date().getTime();  
const distance = anniversaryDate - now;  

if (distance <= 0) {  
    countdown.innerHTML = `  
        <div class="countdown-item">  
            <span>❤️</span>  
            <small>Hari spesial kita telah tiba!</small>  
        </div>  
    `;  
    return;  
}  

const days = Math.floor(distance / (1000 * 60 * 60 * 24));  
const hours = Math.floor(  
    (distance % (1000 * 60 * 60 * 24)) /  
    (1000 * 60 * 60)  
);  
const minutes = Math.floor(  
    (distance % (1000 * 60 * 60)) /  
    (1000 * 60)  
);  
const seconds = Math.floor(  
    (distance % (1000 * 60)) / 1000  
);  

countdown.innerHTML = `  
    <div class="countdown-item">  
        <span>${days}</span>  
        <small>Hari</small>  
    </div>  

    <div class="countdown-item">  
        <span>${hours}</span>  
        <small>Jam</small>  
    </div>  

    <div class="countdown-item">  
        <span>${minutes}</span>  
        <small>Menit</small>  
    </div>  

    <div class="countdown-item">  
        <span>${seconds}</span>  
        <small>Detik</small>  
    </div>  
`;

}

updateCountdown();
setInterval(updateCountdown, 1000);

// ==========================================
// 2. GALERI FOTO DARI HTML
// ==========================================

const photoGrid = document.getElementById("photoGrid");
const photoCount = document.getElementById("photoCount");

if (photoGrid) {
const photoSlots = photoGrid.querySelectorAll(".photo-slot");

function updatePhotoCount() {  
    const loaded = photoGrid.querySelectorAll(  
        ".photo-slot img.loaded"  
    ).length;  

    if (photoCount) {  
        photoCount.textContent = loaded + " Foto Kenangan ❤️";  
    }  
}  

photoSlots.forEach(function (slot) {  
    const img = slot.querySelector("img");  
    const placeholder = slot.querySelector(".photo-placeholder");  

    if (!img) return;  

    function showPhoto() {  
        img.classList.add("loaded");  

        if (placeholder) {  
            placeholder.style.display = "none";  
        }  

        updatePhotoCount();  
    }  

    function showPlaceholder() {  
        img.classList.remove("loaded");  

        if (placeholder) {  
            placeholder.style.display = "flex";  
        }  

        updatePhotoCount();  
    }  

    img.addEventListener("load", showPhoto);  
    img.addEventListener("error", showPlaceholder);  

    if (img.complete) {  
        if (img.naturalWidth > 0) {  
            showPhoto();  
        } else {  
            showPlaceholder();  
        }  
    }  
});

}

// ==========================================
// 3. LIGHTBOX UNTUK MEMPERBESAR FOTO
// ==========================================

const lightbox = document.getElementById("lightbox");
const lightboxImage = document.getElementById("lightboxImage");
const lightboxCaption = document.getElementById("lightboxCaption");

if (photoGrid && lightbox && lightboxImage) {
photoGrid.addEventListener("click", function (event) {
const img = event.target.closest("img");

if (!img || !img.complete || img.naturalWidth === 0) {  
        return;  
    }  

    lightboxImage.src = img.src;  

    if (lightboxCaption) {  
        lightboxCaption.textContent = img.alt;  
    }  

    lightbox.classList.add("active");  
});

}

// Menutup foto yang diperbesar
if (lightbox) {
lightbox.addEventListener("click", function (event) {
if (
event.target === lightbox ||
event.target.closest(".lightbox-close")
) {
lightbox.classList.remove("active");
if (lightboxImage) {
lightboxImage.src = "";
}
}
});
}

// Menutup lightbox menggunakan tombol ESC
document.addEventListener("keydown", function (event) {
if (event.key === "Escape" && lightbox) {
lightbox.classList.remove("active");

if (lightboxImage) {  
        lightboxImage.src = "";  
    }  
}

});

// ==========================================
// 4. ANIMASI HATI DI LATAR BELAKANG
// ==========================================

const backgroundHearts = document.getElementById("backgroundHearts");
if (backgroundHearts) {
const heartSymbols = ["♡", "♥", "💕"];

for (let i = 0; i < 20; i++) {  
    const heart = document.createElement("span");  

    heart.className = "heart";
    heart.textContent =  
        heartSymbols[Math.floor(Math.random() * heartSymbols.length)];  

    heart.style.left = Math.random() * 100 + "%";  
    heart.style.animationDuration = (8 + Math.random() * 12) + "s";  
    heart.style.animationDelay = (Math.random() * 10) + "s";  
    heart.style.fontSize = (12 + Math.random() * 18) + "px";  

    backgroundHearts.appendChild(heart);  
}

}

// ==========================================
// 5. ANIMASI SAAT BAGIAN WEBSITE MUNCUL
// ==========================================

const sections = document.querySelectorAll(".section, .hero");

if ("IntersectionObserver" in window) {
const observer = new IntersectionObserver(
function (entries) {
entries.forEach(function (entry) {
if (entry.isIntersecting) {
entry.target.classList.add("visible");
}
});
},
{
threshold: 0.1
}
);

sections.forEach(function (section) {  
    observer.observe(section);  
});

}

// ==========================================
// 6. NAVIGASI MENU MOBILE
// ==========================================

function toggleMenu() {
const navLinks = document.querySelector(".nav-links");

if (navLinks) {  
    navLinks.classList.toggle("active");  
}

}

// ==========================================
// 7. VIDEO PEMBUKA
// ==========================================

const openingVideo = document.querySelector(".hero video");

if (openingVideo) {
openingVideo.muted = true;

const playPromise = openingVideo.play();  

if (playPromise !== undefined) {  
    playPromise.catch(function () {  
        // Beberapa browser memerlukan interaksi pengguna  
        // sebelum video dapat diputar otomatis.  
    });  
}

}

// ==========================================
// 8. VIDEO KENANGAN
// ==========================================

const memoryVideo = document.querySelector(".video-section video");

if (memoryVideo) {
memoryVideo.addEventListener("error", function () {
console.log(
"Video tidak dapat dimuat. Periksa folder video dan nama file."
);
});
}

console.log("BECHAROUND berhasil dijalankan ❤️");
